package com.sathidar.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sathidar.model.UpdateMember;

@Repository
public interface UpdateMemberRepository extends JpaRepository<UpdateMember, Integer> {

	@Transactional
	@Modifying
	@Query(value = "update memberdetails set  membernative= :mNative, height= :mHeight, weight= :mWeight, lifestyles= :mLifeStyles, "
			+ " known_languages= :mKnown_Languages, education= :mEducation, job= :mJob, income= :mIncome, hobbies= :mHobbies , expectations= :mExpectation,"
			+ " mother_tounge= :mMother_tounge, marital_status= :mMarital_status, no_of_children= :mNoOfChildren, date_of_birth= :mDateOfBirth,  age= :mAge,"
			+ " religion_id= :mReligionID, cast_id= :mCasteID, subcaste_id= :mSubCasteID, state_id= :mStateID, city_id= :mCityID"
			+ " where member_id= :id  ", nativeQuery = true)
	Object UpdateMemberDetails(String mNative, double mHeight, double mWeight, String mLifeStyles,
			String mKnown_Languages, String mEducation, String mJob, String mIncome, String mHobbies,
			String mExpectation, int id,
			String mMother_tounge, String mMarital_status, String mNoOfChildren,
			String mDateOfBirth, int mAge, int mReligionID, int mCasteID, int mSubCasteID, int mStateID, int mCityID
			);
	
	@Query(value="SELECT * FROM memberdetails as md join member as m on md.member_id=m.member_id where m.member_number= :member_number and m.status='ACTIVE'",nativeQuery=true)
	UpdateMember getDetailsByMemberID(String member_number);
	
	@Query(value="SELECT religion_id FROM religion where religion_name= :religionName and status='ACTIVE'",nativeQuery=true)
	int getReligionID(String religionName);

	@Query(value="SELECT subcast_id FROM subcasts where subcast_name= :subCasteName and cast_id= :casteID  and status='ACTIVE'",nativeQuery=true)
	int getSubCasteID(String subCasteName, int casteID);

	@Query(value="SELECT state_id FROM states where state_name= :stateName and status='ACTIVE'",nativeQuery=true)
	int getStateID(String stateName);

	@Query(value="SELECT city_id FROM city where city_name= :cityName and state_id= :stateID and status='ACTIVE'",nativeQuery=true)
	int getCityID(String cityName, int stateID);

	@Query(value="SELECT cast_id FROM cast where cast_name= :casteName and religion_id= :religionID  and status='ACTIVE'",nativeQuery=true)
	int getCasteIDByReligionID(String casteName, int religionID);

}