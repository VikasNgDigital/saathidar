package com.sathidar.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sathidar.EntityMangerFactory.GetNameByIDMangerFactory;
import com.sathidar.exception.BadRequestException;
import com.sathidar.model.MemberPreferenceModel;
import com.sathidar.model.UpdateMember;
import com.sathidar.repository.MemberPreferenceRepository;

@Service
public class MemberPreferenceImpl implements MemberPreferenceService {

	@Autowired
	private MemberPreferenceRepository memberPreferenceRepository;

	@Autowired
	private GetNameByIDMangerFactory getNameByIDMangerFactory;
	
	@Override
	public Object updateMemberPreference(MemberPreferenceModel memberPreferenceModel, int id) {

		String gender="",lifestyle="",job="",education="";
		int cast_id=0,subcaste_id=0,religion_id=0,state_id=0,city_id=0,fromage=0,toage=0;
		Object MemberPreferenceObject=null;
		try {
			gender=memberPreferenceModel.getGender().trim();
			lifestyle=memberPreferenceModel.getLifestyle().trim();
			job=memberPreferenceModel.getJob().trim();
			education=memberPreferenceModel.getEducation();
			
			cast_id= getNameByIDMangerFactory.getCasteID(memberPreferenceModel.getCast_name().trim());
			subcaste_id= getNameByIDMangerFactory.getSubCasteIdByName(memberPreferenceModel.getSub_cast_name().trim());
			religion_id= getNameByIDMangerFactory.getReligionID(memberPreferenceModel.getReligion_name().trim());
			state_id= getNameByIDMangerFactory.getStateIdByName(memberPreferenceModel.getState_name().trim());
			city_id= getNameByIDMangerFactory.getCityidByName(memberPreferenceModel.getCity_name().trim());
			
			fromage=memberPreferenceModel.getFromage();
			toage=memberPreferenceModel.getToage();
					
		    MemberPreferenceObject = memberPreferenceRepository.updateMemberPreference(id,gender,lifestyle,job,education,
					cast_id,subcaste_id,religion_id,state_id,city_id,fromage,toage);

			if (MemberPreferenceObject == null) {
				throw new BadRequestException("member preference not updated");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return MemberPreferenceObject;
	}

//	@Override
//	public MemberPreferenceModel getMemberPreferenceDetails(int id) {
//		return memberPreferenceRepository.getMemberPreferenceDetails(id);
//	}
}
