package com.sathidar.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sathidar.EntityMangerFactory.UpdateMemberEntityMangerFactory;
import com.sathidar.model.UpdateMember;
import com.sathidar.model.User;
import com.sathidar.service.UpdateMemberService;

@RestController
@RequestMapping("/api")
public class UpdateMemberController {

	@Autowired
	private UpdateMemberService updateMemberService;
	
	@Autowired
	private UpdateMemberEntityMangerFactory updateMemberEntityMangerFactory;
	
	@PostMapping(path = "/member/update/{id}")
	public Map<String, String> updateMember(@Validated @RequestBody UpdateMember updateMember,@PathVariable("id") int id) {
		  HashMap<String, String> map = new HashMap<>();
		if(updateMemberService.UpdateMemberDetails(updateMember,id) !=null) {
			 map.put("message", "Member Updated...");
		}else {
			map.put("message", "Something wrong , please try again....");
		}
		return map;
	}
	
//	@GetMapping(value = "/member/get-details/{id}")
//	public List<UpdateMember> getAllUsers(@PathVariable("id") int id) {
//		return updateMemberService.getMemberDetails(id);
//	}

	@GetMapping(value = "/member/get-details/{id}")
	public Map<String, String> getMembers(@PathVariable("id") int id) {
		 HashMap<String, String> map = new HashMap<>();
		 map=updateMemberEntityMangerFactory.getMember(id);
		 if(map==null) {
			 map.put("message","something wrong ! record not fetch...");
		 }
		 return map;
	}
	
	
	@GetMapping(value = "/member/get-details-by-member-id/{member_number}")
	public UpdateMember getDetailsByMemberID(@PathVariable("member_number") String member_number) {
		return updateMemberService.getDetailsByMemberID(member_number);
	}
	
	@PostMapping(value = "/member/get-all-member/{id}")
	public String getAllMemberByFilter(@Validated @RequestBody UpdateMember updateMember,@PathVariable("id") int id) {
		 JSONArray jsonResultArray = new JSONArray();
		 jsonResultArray=updateMemberEntityMangerFactory.getAllMemberByFilter(updateMember,id);
		 return jsonResultArray.toString();
	}

	@GetMapping(value = "/member/get-all-member-by-opposite-gender/{id}")
	public String getAllMembers(@PathVariable("id") int id) {
		 JSONArray jsonResultArray = new JSONArray();
		 jsonResultArray=updateMemberEntityMangerFactory.getAllMembers(id);
		 return jsonResultArray.toString();
	}

	
	
}
