package com.sathidar.service;

import java.text.DecimalFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sathidar.model.UpdateMember;
import com.sathidar.repository.UpdateMemberRepository;

@Service
public class UpdateMemberServiceImpl implements UpdateMemberService {

	@Autowired
	UpdateMemberRepository updateMemberRepository;

	@Override
	public Object UpdateMemberDetails(UpdateMember updateMember, int id) {

		double dHeight = 0.0, dWeight = 0.0, mHeight = 0.0, mWeight = 0.0;
		String mNative = "", mLifeStyles = "", mKnown_Languages = "", mEducation = "", mJob = "", mIncome = "",
				mHobbies = "", mother_tounge = "", marital_status = "", noOfChildren = "", dateOfBirth = "",
				mExpectation = "";
		int religionID = 0, casteID = 0, subCasteID = 0, stateID = 0, cityID = 0, age = 0;

		try {

			updateMember.setId(id);
			mNative = updateMember.getMembernative().trim();

			dHeight = updateMember.getHeight();
			DecimalFormat dfHeight = new DecimalFormat("#.##");
			mHeight = Double.parseDouble(dfHeight.format(dHeight));

			dWeight = updateMember.getWeight();
			DecimalFormat dfWeight = new DecimalFormat("#.##");
			mWeight = Double.parseDouble(dfWeight.format(dWeight));

			mLifeStyles = updateMember.getLifestyles().trim();
			mKnown_Languages = updateMember.getKnown_languages().trim();
			mEducation = updateMember.getEducation().trim();
			mJob = updateMember.getJob().trim();
			mIncome = updateMember.getIncome().trim();
			mHobbies = updateMember.getHobbies().trim();
			mExpectation = updateMember.getExpectations().trim();
			// ------- 23-3-2022 start------------
			religionID = updateMemberRepository.getReligionID(updateMember.getReligion_name().trim());
			casteID = updateMemberRepository.getCasteIDByReligionID(updateMember.getCaste_name().trim(), religionID);
			subCasteID = updateMemberRepository.getSubCasteID(updateMember.getSub_caste_name().trim(), casteID);
			stateID = updateMemberRepository.getStateID(updateMember.getState_name().trim());
			cityID = updateMemberRepository.getCityID(updateMember.getCity_name().trim(), stateID);

			mother_tounge = updateMember.getMother_tounge().trim();
			marital_status = updateMember.getMarital_status().trim();
			noOfChildren = updateMember.getNo_of_children().trim();
			dateOfBirth = updateMember.getDate_of_birth().trim();
			age = Integer.parseInt(updateMember.getAge() + "".trim());

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return updateMemberRepository.UpdateMemberDetails(mNative, mHeight, mWeight, mLifeStyles, mKnown_Languages,
				mEducation, mJob, mIncome, mHobbies, mExpectation, id, mother_tounge, marital_status, noOfChildren,
				dateOfBirth, age, religionID, casteID, subCasteID, stateID, cityID);
		// ------- 23-3-2022 end------------

//		return updateMemberRepository.UpdateMemberDetails(mNative,mHeight,mWeight,mLifeStyles,mKnown_Languages,mEducation,mJob,mIncome,mHobbies,mExpectation, id);
	}

	@Override
	public UpdateMember getDetailsByMemberID(String member_number) {
		return updateMemberRepository.getDetailsByMemberID(member_number);
	}
}
