package com.sathidar.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sathidar.model.MemberPreferenceModel;
import com.sathidar.model.UpdateMember;

@Repository
public interface MemberPreferenceRepository extends JpaRepository<MemberPreferenceModel, Integer> {

	
	@Transactional
	@Modifying
	@Query(value="update member_preference set gender= :gender,lifestyle= :lifestyle,job= :job,education= :education,"
			+ "cast_id= :cast_id,subcaste_id= :subcaste_id,religion_id= :religion_id,state_id= :state_id,city_id= :city_id,"
			+ "fromage= :fromage,toage= :toage,status='ACTIVE' where member_id= :member_id",nativeQuery = true)
	Object updateMemberPreference(int member_id, String gender, String lifestyle, String job, String education, int cast_id,
			int subcaste_id, int religion_id, int state_id, int city_id, int fromage, int toage);
}

