package com.sathidar.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;

@Entity
public class UpdateMember {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	private String membernative;
	
	private Double height;
	
	private Double weight;
	
	private String lifestyles;
	
	private String known_languages;
	
	private String education;
	
	private String job;
	
	private String income;
	
	private String hobbies;
	
	private String expectations;

	private String first_name;
	
	private String last_name;
	
	private String gender;
	
	private Integer age;
	
	private String marital_status;
	
	private String contact_number;
	
	private String email_id;
	
	private String profilecreatedby;
	
	private Integer cast_id;
	
	private Integer subcaste_id;
	
//	------- 23-3-2022 start------------

	private Integer religion_id;
	
	@Transient
	private String religion_name;

	@Transient
	private String caste_name;
	
	@Transient
	private String sub_caste_name;
	
	@Transient
	private String state_name;
	
	private String state_Id;

	@Transient
	private String city_name;

	private String city_Id;
	
	private String mother_tounge;
	
	private String no_of_children;
	
	private String date_of_birth;
	
	@Transient
	private String from_age;

	@Transient
	private String to_age;

	@Transient
	private String lookingFor;
//	------- 23-3-2022 end------------

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMembernative() {
		return membernative;
	}

	public void setMembernative(String membernative) {
		this.membernative = membernative;
	}

	public Double getHeight() {
		return height;
	}

	public void setHeight(Double height) {
		this.height = height;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public String getLifestyles() {
		return lifestyles;
	}

	public void setLifestyles(String lifestyles) {
		this.lifestyles = lifestyles;
	}

	public String getKnown_languages() {
		return known_languages;
	}

	public void setKnown_languages(String known_languages) {
		this.known_languages = known_languages;
	}

	public String getEducation() {
		return education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public String getIncome() {
		return income;
	}

	public void setIncome(String income) {
		this.income = income;
	}

	public String getHobbies() {
		return hobbies;
	}

	public void setHobbies(String hobbies) {
		this.hobbies = hobbies;
	}

	public String getExpectations() {
		return expectations;
	}

	public void setExpectations(String expectations) {
		this.expectations = expectations;
	}

	
	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getMarital_status() {
		return marital_status;
	}

	public void setMarital_status(String marital_status) {
		this.marital_status = marital_status;
	}

	public String getContact_number() {
		return contact_number;
	}

	public void setContact_number(String contact_number) {
		this.contact_number = contact_number;
	}

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public String getProfilecreatedby() {
		return profilecreatedby;
	}

	public void setProfilecreatedby(String profilecreatedby) {
		this.profilecreatedby = profilecreatedby;
	}

	public Integer getCast_id() {
		return cast_id;
	}

	public void setCast_id(Integer cast_id) {
		this.cast_id = cast_id;
	}

	public Integer getSubcaste_id() {
		return subcaste_id;
	}

	public void setSubcaste_id(Integer subcaste_id) {
		this.subcaste_id = subcaste_id;
	}
	
	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public Integer getReligion_id() {
		return religion_id;
	}

	public void setReligion_id(Integer religion_id) {
		this.religion_id = religion_id;
	}

	public String getMother_tounge() {
		return mother_tounge;
	}

	public void setMother_tounge(String mother_tounge) {
		this.mother_tounge = mother_tounge;
	}
	public String getState_Id() {
		return state_Id;
	}

	public void setState_Id(String state_Id) {
		this.state_Id = state_Id;
	}

	public String getCity_Id() {
		return city_Id;
	}

	public void setCity_Id(String city_Id) {
		this.city_Id = city_Id;
	}

	public String getReligion_name() {
		return religion_name;
	}

	public void setReligion_name(String religion_name) {
		this.religion_name = religion_name;
	}

	public String getCaste_name() {
		return caste_name;
	}

	public void setCaste_name(String caste_name) {
		this.caste_name = caste_name;
	}

	public String getSub_caste_name() {
		return sub_caste_name;
	}

	public void setSub_caste_name(String sub_caste_name) {
		this.sub_caste_name = sub_caste_name;
	}

	public String getState_name() {
		return state_name;
	}

	public void setState_name(String state_name) {
		this.state_name = state_name;
	}

	public String getCity_name() {
		return city_name;
	}

	public void setCity_name(String city_name) {
		this.city_name = city_name;
	}

	public String getNo_of_children() {
		return no_of_children;
	}

	public void setNo_of_children(String no_of_children) {
		this.no_of_children = no_of_children;
	}

	public String getDate_of_birth() {
		return date_of_birth;
	}

	public void setDate_of_birth(String date_of_birth) {
		this.date_of_birth = date_of_birth;
	}
	
	public String getFrom_age() {
		return from_age;
	}

	public void setFrom_age(String from_age) {
		this.from_age = from_age;
	}

	public String getTo_age() {
		return to_age;
	}

	public void setTo_age(String to_age) {
		this.to_age = to_age;
	}

	public String getLookingFor() {
		return lookingFor;
	}

	public void setLookingFor(String lookingFor) {
		this.lookingFor = lookingFor;
	}

	public UpdateMember(Integer id, String membernative, Double height, Double weight, String lifestyles,
			String known_languages, String education, String job, String income, String hobbies, String expectations,
			String first_name, String last_name, String gender, Integer age, String marital_status,
			String contact_number, String email_id, String profilecreatedby, Integer cast_id, Integer subcaste_id,
			Integer religion_id, String religion_name, String caste_name, String sub_caste_name, String state_name,
			String state_Id, String city_name, String city_Id, String mother_tounge, String no_of_children,
			String date_of_birth, String from_age, String to_age, String lookingFor) {
		super();
		this.id = id;
		this.membernative = membernative;
		this.height = height;
		this.weight = weight;
		this.lifestyles = lifestyles;
		this.known_languages = known_languages;
		this.education = education;
		this.job = job;
		this.income = income;
		this.hobbies = hobbies;
		this.expectations = expectations;
		this.first_name = first_name;
		this.last_name = last_name;
		this.gender = gender;
		this.age = age;
		this.marital_status = marital_status;
		this.contact_number = contact_number;
		this.email_id = email_id;
		this.profilecreatedby = profilecreatedby;
		this.cast_id = cast_id;
		this.subcaste_id = subcaste_id;
		this.religion_id = religion_id;
		this.religion_name = religion_name;
		this.caste_name = caste_name;
		this.sub_caste_name = sub_caste_name;
		this.state_name = state_name;
		this.state_Id = state_Id;
		this.city_name = city_name;
		this.city_Id = city_Id;
		this.mother_tounge = mother_tounge;
		this.no_of_children = no_of_children;
		this.date_of_birth = date_of_birth;
		this.from_age = from_age;
		this.to_age = to_age;
		this.lookingFor = lookingFor;
	}

	public UpdateMember() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
