package com.sathidar.service;

import com.sathidar.model.MemberPreferenceModel;
import com.sathidar.model.UpdateMember;

public interface MemberPreferenceService {

	Object updateMemberPreference(MemberPreferenceModel memberPreferenceModel, int id);

}
