package com.sathidar.EntityMangerFactory;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

@Service
public class MemberPreferenceManagerFactory {

	@PersistenceContext
	private EntityManager em;

	public JSONArray getMemberPreferenceDetails(int memberID) {

		String columnName = "mp.gender,lifestyle,job,education,fromage,toage,"
				+ "(select cast_name from cast where cast_id=(select cast_id from member_preference where member_id= :memberID and status='ACTIVE')) as castName,"
				+ "(select subcast_name from subcasts where subcast_id=(select subcaste_id from member_preference where member_id= :memberID and status='ACTIVE')) as subcastName,"
				+ "(select religion_name from religion where religion_id=(select religion_id from member_preference where member_id= :memberID and status='ACTIVE')) as religionName,"
				+ "(select state_name from states where state_id=(select state_id from member_preference where member_id= :memberID and status='ACTIVE')) as stateName,"
				+ "(select city_name from city where city_id=(select city_id from member_preference where member_id= :memberID and status='ACTIVE')) as cityName"
				+ " ";

		Query q = em.createNativeQuery("select " + columnName
				+ " from member_preference as mp join member as m on mp.member_id=m.member_id where mp.member_id= :memberID and  m.status='ACTIVE' and mp.status='ACTIVE'");
		q.setParameter("memberID", memberID);

//		System.out.println("select " + columnName
//				+ " from member_preference as mp join member as m on mp.member_id=m.member_id where mp.member_id= :memberID and  m.status='ACTIVE' and mp.status='ACTIVE'");
		JSONArray resultArray = new JSONArray();
		List<Object[]> results = q.getResultList();

		boolean status = false;
		if (results != null) {
			for (Object[] obj : results) {
				JSONObject json = new JSONObject();
				int i = 0;
				json.put("gender", String.valueOf(obj[i]));
				json.put("lifestyle", String.valueOf(obj[++i]));
				json.put("job", String.valueOf(obj[++i]));
				json.put("education", String.valueOf(obj[++i]));
				json.put("fromage", String.valueOf(obj[++i]));
				json.put("toage", String.valueOf(obj[++i]));
				json.put("castName", String.valueOf(obj[++i]));
				json.put("subcastName", String.valueOf(obj[++i]));
				json.put("religionName", String.valueOf(obj[++i]));
				json.put("stateName", String.valueOf(obj[++i]));
				json.put("cityName", String.valueOf(obj[++i]));
				resultArray.put(json);
				status = true;
			}
		}
		if (status == false) {
			JSONObject json = new JSONObject();
			json.put("message", "Record not found");
			resultArray.put(json);
		}

		return resultArray;
	}

	@Transactional
	public JSONArray deleteMemberPreferenceDetails(int member_id) {
		int statusCount=0;
		JSONArray resultArray = new JSONArray();
		try {
			Query queryMemberDeativate = em.createNativeQuery(
					"update member_preference set status='DEACTIVATE' where member_id= :memberID and status='ACTIVE'");
			System.out.println("update member_preference set status='DEACTIVATE' where member_id= :memberID and status='ACTIVE'");
			queryMemberDeativate.setParameter("memberID", member_id);
			statusCount = queryMemberDeativate.executeUpdate();
			JSONObject json = new JSONObject();
			if(statusCount>0) {
				json.put("message", "preference deleted..");
				resultArray.put(json);
			}else {
				json.put("message", "record not deleted..");
				resultArray.put(json);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultArray;
	}

}
