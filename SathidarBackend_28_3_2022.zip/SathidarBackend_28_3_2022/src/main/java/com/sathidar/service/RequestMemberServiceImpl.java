package com.sathidar.service;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sathidar.EntityMangerFactory.RequestBlockMemberEntityManagerFactory;
import com.sathidar.exception.BadRequestException;
import com.sathidar.model.RequestMemberModel;
import com.sathidar.repository.RequestMemberRepository;

@Service
public class RequestMemberServiceImpl implements RequestMemberService {

	@Autowired
	private RequestMemberRepository requestMemberRepository;

	@Autowired
	private RequestBlockMemberEntityManagerFactory requestBlockMemberEntityManagerFactory;

	@Override
	public JSONArray SendRequestToMember(RequestMemberModel requestMemberModel) {

		Object requestMemberObject = null;
		JSONArray resultArray = new JSONArray();

		try {
			JSONObject json = new JSONObject();
			int request_from_id = requestMemberModel.getRequest_from_id();
			int request_to_id = requestMemberModel.getRequest_to_id();
			String request_status = requestMemberModel.getRequest_status().trim();
			requestMemberObject = requestMemberRepository.sendRequestToMember(request_from_id, request_to_id,
					request_status);
			json.put("message", "request are send..");

			if (requestMemberObject == null) {
				throw new BadRequestException("request not send..");
			}

			resultArray.put(json);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultArray;
	}

	@Override
	public JSONArray RequestAcceptAndRejected(RequestMemberModel requestMemberModel) {
		Object requestMemberObject = null;
		JSONArray resultArray = new JSONArray();

		try {
			JSONObject json = new JSONObject();
			int request_from_id = requestMemberModel.getRequest_from_id();
			int request_to_id = requestMemberModel.getRequest_to_id();
			String request_status = requestMemberModel.getRequest_status().trim();
			requestMemberObject = requestMemberRepository.requestAcceptedAndRejected(request_from_id, request_to_id,
					request_status);
			json.put("message", "request are " + request_status + "..");

			if (requestMemberObject == null) {
				throw new BadRequestException("something wrong request not working..");
			}

			resultArray.put(json);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultArray;
	}

	@Override
	public JSONArray blockMember(RequestMemberModel requestMemberModel) {
		Object requestMemberObject = null;
		JSONArray resultArray = new JSONArray();

		try {
			JSONObject json = new JSONObject();
			int request_from_id = requestMemberModel.getRequest_from_id();
			int request_to_id = requestMemberModel.getRequest_to_id();
			int block_by_id = requestMemberModel.getBlock_by_id();
			String block_status = requestMemberModel.getBlock_status().trim();

			List<Object[]> objResults = requestBlockMemberEntityManagerFactory
					.getFromRequestAndToRequest(request_from_id, request_to_id);
			if (objResults != null) {
				for (Object[] obj : objResults) {
					int from_id = (int) obj[0];
					int to_id = (int) obj[1];

					requestMemberObject = requestMemberRepository.requestBlockToMember(from_id, to_id, block_by_id,
							block_status);
					if (requestMemberObject != null)
						json.put("message", "request is " + block_status + "..");
				}
			} else {
				throw new BadRequestException("something wrong block/unblock request not working..");
			}

			if (requestMemberObject == null) {
				throw new BadRequestException("something wrong block/unblock request not working..");
			}

			resultArray.put(json);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultArray;
	}

}
