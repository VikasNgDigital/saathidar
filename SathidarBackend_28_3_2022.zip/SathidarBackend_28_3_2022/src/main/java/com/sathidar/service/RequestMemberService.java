package com.sathidar.service;

import org.json.JSONArray;

import com.sathidar.model.RequestMemberModel;

public interface RequestMemberService {

	JSONArray SendRequestToMember(RequestMemberModel requestMemberModel);

	JSONArray RequestAcceptAndRejected(RequestMemberModel requestMemberModel);

	JSONArray blockMember(RequestMemberModel requestMemberModel);

}
