package com.sathidar.EntityMangerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;
import com.sathidar.model.UpdateMember;

@Service
public class UpdateMemberEntityMangerFactory {

	@PersistenceContext
	private EntityManager em;

	public HashMap<String, String> getMember(int id) {
		HashMap<String, String> map = new HashMap<>();

		String columnName = " membernative,height,weight,lifestyles,known_languages,education,job,income,hobbies,expectations,first_name,last_name,gender,md.age as mage,"
				+ "contact_number,email_id,profilecreatedby,md.marital_status as maritalStatus,no_of_children,mother_tounge,date_of_birth,"
				+ "(select cast_name from cast where cast_id=(select cast_id from memberdetails where member_id= :id )) as caste,"
				+ "(select subcast_name from subcasts where subcast_id=(select subcaste_id from memberdetails where member_id= :id)) as subcaste,"
				+ "(select religion_name from religion where religion_id=(select religion_id from memberdetails where member_id= :id)) as religion,"
				+ "(select state_name from states where state_id=(select state_id from memberdetails where member_id= :id)) as state,"
				+ "(select city_name from city where city_id=(select city_id from memberdetails where member_id= :id)) as city";
		try {
			Query q = em.createNativeQuery("SELECT " + columnName
					+ "  FROM memberdetails as md join member as m on md.member_id=m.member_id where md.member_id= :id and m.status='ACTIVE'");
//			System.out.println(q);
			q.setParameter("id", id);
			boolean status = false;
			List<Object[]> results = q.getResultList();
			if (results != null) {
				for (Object[] obj : results) {
					int i = 0;
					map.put("native", String.valueOf(obj[i]));
					map.put("height", String.valueOf(obj[++i]));
					map.put("weight", String.valueOf(obj[++i]));
					map.put("lifestyles", String.valueOf(obj[++i]));
					map.put("known_languages", String.valueOf(obj[++i]));
					map.put("education", String.valueOf(obj[++i]));
					map.put("job", String.valueOf(obj[++i]));
					map.put("income", String.valueOf(obj[++i]));
					map.put("hobbies", String.valueOf(obj[++i]));
					map.put("expectations", String.valueOf(obj[++i]));
					map.put("first_name", String.valueOf(obj[++i]));
					map.put("last_name", String.valueOf(obj[++i]));
					map.put("gender", String.valueOf(obj[++i]));
					map.put("mage", String.valueOf(obj[++i]));
					map.put("contact_number", String.valueOf(obj[++i]));
					map.put("email_id", String.valueOf(obj[++i]));
					map.put("profilecreatedby", String.valueOf(obj[++i]));
					map.put("maritalStatus", String.valueOf(obj[++i]));
					map.put("no_of_children", String.valueOf(obj[++i]));
					map.put("mother_tounge", String.valueOf(obj[++i]));
					map.put("date_of_birth", String.valueOf(obj[++i]));
					map.put("caste", String.valueOf(obj[++i]));
					map.put("subcaste", String.valueOf(obj[++i]));
					map.put("religion", String.valueOf(obj[++i]));
					map.put("state", String.valueOf(obj[++i]));
					map.put("city", String.valueOf(obj[++i]));
					status = true;
				}
			}

			if (status == false) {
				map.put("message", "record not found");
			}

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return map;
	}

	public JSONArray getAllMemberByFilter(UpdateMember updateMember, int id) {

//		******************************Column Name*************************************************************************
		String columnName = " membernative,height,weight,lifestyles,known_languages,education,job,income,hobbies,expectations,first_name,last_name,gender,md.age as mage,"
				+ "contact_number,email_id,profilecreatedby,md.marital_status as maritalStatus,no_of_children,mother_tounge,date_of_birth,"
				+ "cast_id,subcaste_id,religion_id,state_id,city_id";
//		******************************Filter Data*************************************************************************

		String whereClause = setWhereClauseForGetAllMember(updateMember);

		String likeClause = setLikeClauseForGetAllMember(updateMember);

//		******************************Preference-Recommdations-In-Where-Clause*************************************************************************
//      if recommodations are given in the table then that details are come in where clause

//		******************************Query*************************************************************************
		Query q = em.createNativeQuery(
				"SELECT " + columnName + "  FROM memberdetails as md join member as m on md.member_id=m.member_id "
						+ " where " + whereClause + likeClause + " and md.member_id!= :id and m.status='ACTIVE'");
		System.out.println("SELECT " + columnName
				+ "  FROM memberdetails as md join member as m on md.member_id=m.member_id  where " + whereClause
				+ likeClause + " and md.member_id!= :id and m.status='ACTIVE'");
		q.setParameter("id", id);

		JSONArray resultArray = new JSONArray();
		List<Object[]> results = q.getResultList();
		if (results != null) {
			for (Object[] obj : results) {
				JSONObject json = new JSONObject();
				int i = 0;
				json.put("native", String.valueOf(obj[i]));
				json.put("height", String.valueOf(obj[++i]));
				json.put("weight", String.valueOf(obj[++i]));
				json.put("lifestyles", String.valueOf(obj[++i]));
				json.put("known_languages", String.valueOf(obj[++i]));
				json.put("education", String.valueOf(obj[++i]));
				json.put("job", String.valueOf(obj[++i]));
				json.put("income", String.valueOf(obj[++i]));
				json.put("hobbies", String.valueOf(obj[++i]));
				json.put("expectations", String.valueOf(obj[++i]));
				json.put("first_name", String.valueOf(obj[++i]));
				json.put("last_name", String.valueOf(obj[++i]));
				json.put("gender", String.valueOf(obj[++i]));
				json.put("mage", String.valueOf(obj[++i]));
				json.put("contact_number", String.valueOf(obj[++i]));
				json.put("email_id", String.valueOf(obj[++i]));
				json.put("profilecreatedby", String.valueOf(obj[++i]));
				json.put("maritalStatus", String.valueOf(obj[++i]));
				json.put("no_of_children", String.valueOf(obj[++i]));
				json.put("mother_tounge", String.valueOf(obj[++i]));
				json.put("date_of_birth", String.valueOf(obj[++i]));
				json.put("caste", getCasteNameByID(String.valueOf(obj[++i])));
				json.put("subcaste", getSubCasteNameByID(String.valueOf(obj[++i])));
				json.put("religion", getReligionNameByID(String.valueOf(obj[++i])));
				json.put("state", getStateNameByID(String.valueOf(obj[++i])));
				json.put("city", getCityNameByID(String.valueOf(obj[++i])));
				resultArray.put(json);

			}
		}
		return resultArray;
	}

	private String getCityNameByID(String cityID) {
		String result = "";
		try {
			Query q = em.createNativeQuery("SELECT city_name FROM city where city_id= :cityID and status='ACTIVE'");
			q.setParameter("cityID", cityID);
			result = q.getSingleResult().toString();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	private String getStateNameByID(String stateID) {
		String result = "";
		try {
			Query q = em
					.createNativeQuery("SELECT state_name FROM states where state_id= :stateID and status='ACTIVE'");
			q.setParameter("stateID", stateID);
			result = q.getSingleResult().toString();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	private String getReligionNameByID(String religionID) {
		String result = "";
		try {
			Query q = em.createNativeQuery(
					"select religion_name from religion where religion_id=:religionID and status='ACTIVE'");
			q.setParameter("religionID", religionID);
			result = q.getSingleResult().toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	private String getSubCasteNameByID(String subcast_ID) {
		String result = "";
		try {
			Query q = em.createNativeQuery(
					"SELECT subcast_name FROM subcasts where subcast_id= :subcast_ID and status='ACTIVE'");
			q.setParameter("subcast_ID", subcast_ID);
			result = q.getSingleResult().toString();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	private String getCasteNameByID(String casteID) {
		String result = "";
		try {
			Query q = em.createNativeQuery("SELECT cast_name FROM cast where cast_id= :casteID and status='ACTIVE'");
			q.setParameter("casteID", casteID);
			result = q.getSingleResult().toString();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	private String setLikeClauseForGetAllMember(UpdateMember updateMember) {
		String likeClause = "";
		try {
			if (updateMember.getLifestyles() != null && !updateMember.getLifestyles().equals("")) {
//				if(updateMember.getLifestyles().contains(",")) {
//					String[] splitString = updateMember.getLifestyles().split(",");
//					
//				}else {
				likeClause += " and lifestyles like '%" + updateMember.getLifestyles().trim() + "%'";
//				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return likeClause;
	}

	private String setWhereClauseForGetAllMember(UpdateMember updateMember) {
		String whereClause = "";

		try {
//			if (updateMember.getAge() != null && !updateMember.getAge().equals("")) {
//				whereClause += " md.age=" + updateMember.getAge();
//			}

			String lookingFor = "";
			if (updateMember.getLookingFor() != null && !updateMember.getLookingFor().equals("")) {
				if (updateMember.getLookingFor().equals("Woman")) {
					lookingFor = "female";
					whereClause += " m.gender ='" + lookingFor + "'";
				} else if (updateMember.getLookingFor().equals("Men")) {
					lookingFor = "male";
					whereClause += " m.gender ='" + lookingFor + "'";
				}
			}

			if (updateMember.getMarital_status() != null && !updateMember.getMarital_status().equals("")) {
				whereClause += " and md.marital_status ='" + updateMember.getMarital_status() + "'";
			}

			if (updateMember.getFrom_age() != null && !updateMember.getFrom_age().equals("")) {
				whereClause += " and md.age >=" + updateMember.getFrom_age();
			}

			if (updateMember.getTo_age() != null && !updateMember.getTo_age().equals("")) {
				whereClause += " and md.age <=" + updateMember.getTo_age();
			}

			int casteID = 0, religionID = 0;
			if (updateMember.getReligion_name() != null && !updateMember.getReligion_name().equals("")) {
				religionID = this.getReligionID(updateMember.getReligion_name());
				if (religionID != 0) {
					whereClause += " and religion_id=" + religionID;
				}
			}

			if (updateMember.getCaste_name() != null && !updateMember.getCaste_name().equals("")) {
				if (religionID != 0) {
					casteID = this.getCasteIDByReligionID(updateMember.getCaste_name().trim(), religionID);
				} else {
					casteID = this.getCasteID(updateMember.getCaste_name().trim());
				}
				whereClause += " and cast_id=" + casteID + "";
			}
		} catch (Exception e) {

			e.printStackTrace();
		}
		return whereClause;
	}

	private int getReligionID(String religionName) {
		int result = 0;
		try {
			Query q = em.createNativeQuery(
					"select religion_id from religion where religion_name=:ReligionName and status='ACTIVE'");
			q.setParameter("ReligionName", religionName);
			result = Integer.parseInt(q.getSingleResult().toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	private int getCasteIDByReligionID(String casteName, int religionID) {
		int result = 0;
		try {
			Query q = em.createNativeQuery(
					"SELECT cast_id FROM cast where cast_name= :CasteName and religion_id= :ReligionID  and status='ACTIVE'");
			q.setParameter("CasteName", casteName);
			q.setParameter("ReligionID", religionID);
			result = Integer.parseInt(q.getSingleResult().toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	private int getCasteID(String casteName) {
		int result = 0;
		try {
			Query q = em.createNativeQuery("SELECT cast_id FROM cast where cast_name= :CasteName and status='ACTIVE'");
			q.setParameter("CasteName", casteName);
			result = Integer.parseInt(q.getSingleResult().toString());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	public JSONArray getAllMembers(int id) {

		String whereClause = "";
		String genderName = "";
//		if(!this.getGenderByID(id).equals(""))
//		{
//			if(this.getGenderByID(id).equals("male")) {
//				genderName="female";
//				whereClause += " m.gender ='"+genderName+"'";
//			}else if(this.getGenderByID(id).equals("female")) {
//				genderName="male";
//				whereClause += " m.gender ='"+genderName+"'";
//			}
//		}
//		******************************Column Name*************************************************************************
		String columnName = " md.member_id,membernative,height,weight,lifestyles,known_languages,education,job,income,hobbies,expectations,first_name,last_name,gender,md.age as mage,"
				+ "contact_number,email_id,profilecreatedby,md.marital_status as maritalStatus,no_of_children,mother_tounge,date_of_birth,"
				+ "cast_id,subcaste_id,religion_id,state_id,city_id";

//		******************************Filter Data*************************************************************************

//		******************************Preference-Recommdations-In-Where-Clause*************************************************************************
//      if recommodations are given in the table then that details are come in where clause

//		******************************Query*************************************************************************
		Query q = em.createNativeQuery("SELECT " + columnName
				+ "  FROM memberdetails as md join member as m on md.member_id=m.member_id where md.member_id!= :id");

		// System.out.println("SELECT " + columnName +" FROM memberdetails as md join
		// member as m on md.member_id=m.member_id where "+whereClause+ " and
		// md.member_id!= :id and m.status='ACTIVE'");
		q.setParameter("id", id);

		JSONArray resultArray = new JSONArray();
		List<Object[]> results = q.getResultList();
		if (results != null) {
			for (Object[] obj : results) {
				JSONObject getJson = new JSONObject();
				int member_id=Integer.parseInt(String.valueOf(obj[0]));
				String fieldName = this.getHideContent(member_id);
				if (fieldName != null && !fieldName.equals("")) {
					getJson = this.setHideContent(fieldName, obj);
				} else {
					getJson = this.setContent(obj);
				}
				resultArray.put(getJson);
			}
		}
		return resultArray;
	}

	private JSONObject setContent(Object[] obj) {
		JSONObject setJson = new JSONObject();
		try {
			int i = 1;
			setJson.put("native", String.valueOf(obj[i]));
			setJson.put("height", String.valueOf(obj[++i]));
			setJson.put("weight", String.valueOf(obj[++i]));
			setJson.put("lifestyles", String.valueOf(obj[++i]));
			setJson.put("known_languages", String.valueOf(obj[++i]));
			setJson.put("education", String.valueOf(obj[++i]));
			setJson.put("job", String.valueOf(obj[++i]));
			setJson.put("income", String.valueOf(obj[++i]));
			setJson.put("hobbies", String.valueOf(obj[++i]));
			setJson.put("expectations", String.valueOf(obj[++i]));
			setJson.put("first_name", String.valueOf(obj[++i]));
			setJson.put("last_name", String.valueOf(obj[++i]));
			setJson.put("gender", String.valueOf(obj[++i]));
			setJson.put("mage", String.valueOf(obj[++i]));
			setJson.put("contact_number", String.valueOf(obj[++i]));
			setJson.put("email_id", String.valueOf(obj[++i]));
			setJson.put("profilecreatedby", String.valueOf(obj[++i]));
			setJson.put("maritalStatus", String.valueOf(obj[++i]));
			setJson.put("no_of_children", String.valueOf(obj[++i]));
			setJson.put("mother_tounge", String.valueOf(obj[++i]));
			setJson.put("date_of_birth", String.valueOf(obj[++i]));
			setJson.put("caste", getCasteNameByID(String.valueOf(obj[++i])));
			setJson.put("subcaste", getSubCasteNameByID(String.valueOf(obj[++i])));
			setJson.put("religion", getReligionNameByID(String.valueOf(obj[++i])));
			setJson.put("state", getStateNameByID(String.valueOf(obj[++i])));
			setJson.put("city", getCityNameByID(String.valueOf(obj[++i])));

		} catch (Exception e) {
			e.printStackTrace();
		}
		return setJson;
	}

	private JSONObject setHideContent(String fieldName, Object[] obj) {
		JSONObject setJson = new JSONObject();
		try {
//			String[] splitArray = new String[26];
//
//			if (fieldName.contains(",")) {
//				splitArray = fieldName.split(",");
//			} else {
//				splitArray = new String[] { fieldName };
//			}
//
//			for (int k = 0; k <= splitArray.length; k++) {
				int i = 1;
				if (fieldName.contains("native"))
					setJson.put("native", "");
				else
					setJson.put("native", String.valueOf(obj[i]));

				if (fieldName.contains("height")) {
					setJson.put("height", "");
					++i;
				} else
					setJson.put("height", String.valueOf(obj[++i]));

				if (fieldName.contains("weight")) {
					setJson.put("weight", "");
					++i;
				} else
					setJson.put("weight", String.valueOf(obj[++i]));

				if (fieldName.contains("lifestyles")) {
					setJson.put("lifestyles", "");
					++i;
				} else
					setJson.put("lifestyles", String.valueOf(obj[++i]));

				if (fieldName.contains("known_languages")) {
					setJson.put("known_languages", "");
					++i;
				} else
					setJson.put("known_languages", String.valueOf(obj[++i]));

				if (fieldName.contains("education")) {
					setJson.put("education", "");
					++i;
				} else
					setJson.put("education", String.valueOf(obj[++i]));

				if (fieldName.contains("job")) {
					setJson.put("job", "");
					++i;
				} else
					setJson.put("job", String.valueOf(obj[++i]));

				if (fieldName.contains("income")) {
					setJson.put("income", "");
					++i;
				} else
					setJson.put("income", String.valueOf(obj[++i]));

				if (fieldName.contains("hobbies")) {
					setJson.put("hobbies", "");
					++i;
				} else
					setJson.put("hobbies", String.valueOf(obj[++i]));

				if (fieldName.contains("expectations")) {
					setJson.put("expectations", "");
					++i;
				} else
					setJson.put("expectations", String.valueOf(obj[++i]));

				if (fieldName.contains("first_name")) {
					setJson.put("first_name", "");
					++i;
				} else
					setJson.put("first_name", String.valueOf(obj[++i]));

				if (fieldName.contains("last_name")) {
					setJson.put("last_name", "");
					++i;
				} else
					setJson.put("last_name", String.valueOf(obj[++i]));

				if (fieldName.contains("gender")) {
					setJson.put("gender", "");
					++i;
				} else
					setJson.put("gender", String.valueOf(obj[++i]));

				if (fieldName.contains("mage")) {
					setJson.put("mage", "");
					++i;
				} else
					setJson.put("mage", String.valueOf(obj[++i]));

				if (fieldName.contains("contact_number")) {
					setJson.put("contact_number", "");
					++i;
				} else
					setJson.put("contact_number", String.valueOf(obj[++i]));

				if (fieldName.contains("email_id")) {
					setJson.put("email_id", "");
					++i;
				} else
					setJson.put("email_id", String.valueOf(obj[++i]));

				if (fieldName.contains("profilecreatedby")) {
					setJson.put("profilecreatedby", "");
					++i;
				} else
					setJson.put("profilecreatedby", String.valueOf(obj[++i]));

				if (fieldName.contains("maritalStatus")) {
					setJson.put("maritalStatus", "");
					++i;
				} else
					setJson.put("maritalStatus", String.valueOf(obj[++i]));

				if (fieldName.contains("no_of_children")) {
					setJson.put("no_of_children", "");
					++i;
				} else
					setJson.put("no_of_children", String.valueOf(obj[++i]));

				if (fieldName.contains("mother_tounge")) {
					setJson.put("mother_tounge", "");
					++i;
				} else
					setJson.put("mother_tounge", String.valueOf(obj[++i]));

				if (fieldName.contains("date_of_birth")) {
					setJson.put("date_of_birth", "");
					++i;
				} else
					setJson.put("date_of_birth", String.valueOf(obj[++i]));

				if (fieldName.contains("caste")) {
					setJson.put("caste", "");
					++i;
				} else
					setJson.put("caste", String.valueOf(obj[++i]));

				if (fieldName.contains("subcaste")) {
					setJson.put("subcaste", "");
					++i;
				} else
					setJson.put("subcaste", String.valueOf(obj[++i]));

				if (fieldName.contains("religion")) {
					setJson.put("religion", "");
					++i;
				} else
					setJson.put("religion", String.valueOf(obj[++i]));

				if (fieldName.contains("state")) {
					setJson.put("state", "");
					++i;
				} else
					setJson.put("state", String.valueOf(obj[++i]));

				if (fieldName.contains("city")) {
					setJson.put("city", "");
					++i;
				} else
					setJson.put("city", String.valueOf(obj[++i]));

//			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return setJson;
	}

	private String getHideContent(int id) {
		String columnName = "";
		try {
			Query q = em.createNativeQuery(
					"SELECT column_name  FROM hide_content where member_id= :id and status='ACTIVE'");
			q.setParameter("id", id);
			columnName = q.getSingleResult().toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return columnName;

	}

	private String getGenderByID(int id) {
		String result = "";
		try {
			Query q = em.createNativeQuery(
					"SELECT m.gender  FROM memberdetails as md join member as m on md.member_id=m.member_id where md.member_id= :id and m.status='ACTIVE'");
			q.setParameter("id", id);
			result = q.getSingleResult().toString();
			if (result == null)
				result = "";
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	@Transactional
	public int DeactivateMemberDetails(int userID) {
		int statusCount = 0;
		try {
			int result = 0;
			Query q = em.createNativeQuery("SELECT count(*) FROM users where status='ACTIVE' and id= :userID");
			q.setParameter("userID", userID);
			result = Integer.parseInt(q.getSingleResult().toString());

			if (result > 0) {
				Query queryMemberDeativate = em
						.createNativeQuery("update member set status='Deactivate' where user_id= :userID");
				queryMemberDeativate.setParameter("userID", userID);
				statusCount = queryMemberDeativate.executeUpdate();

				Query queryMemberNumber = em
						.createNativeQuery("update users set status='Deactivate' where id= :userID");
				queryMemberNumber.setParameter("userID", userID);
				statusCount = queryMemberNumber.executeUpdate();
			}
			em.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return statusCount;
	}

	@Transactional
	public int activateMember(String contact_number, String email_id) {
		int statusCount = 0;
		try {
			int result = 0;
			Query q = em.createNativeQuery(
					"SELECT id FROM users where phone= :contact_number and email= :email_id and status='Deactivate'");
			q.setParameter("contact_number", contact_number);
			q.setParameter("email_id", email_id);
			int userID = Integer.parseInt(q.getSingleResult().toString());

			if (userID > 0) {

//				********** send otp on mobile number****************
//				********** send otp on email************************		  
//				if phone otp and email otp are correct then activate member account

				Query queryMemberNumber = em.createNativeQuery(
						"update users set status='ACTIVE' where phone= :contact_number and email= :email_id and status='Deactivate'");
				queryMemberNumber.setParameter("contact_number", contact_number);
				queryMemberNumber.setParameter("email_id", email_id);
				statusCount = queryMemberNumber.executeUpdate();

				Query queryMemberDeativate = em.createNativeQuery(
						"update member set status='ACTIVE' where user_id= :userID and status='Deactivate'");
				queryMemberDeativate.setParameter("userID", userID);
				statusCount = queryMemberDeativate.executeUpdate();

			}
			em.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return statusCount;
	}

}
