package com.sathidar.controller;



import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sathidar.model.RequestMemberModel;
import com.sathidar.service.RequestMemberService;


@RestController
@RequestMapping("/api")
public class RequestMemberController {

	@Autowired
	private RequestMemberService requestMemberService;
	
	@PostMapping(value="/member/send-request")
	private String SendRequestToMember(@Validated @RequestBody RequestMemberModel requestMemberModel) {
		JSONArray jsonResultsArray=new JSONArray();
		jsonResultsArray= requestMemberService.SendRequestToMember(requestMemberModel);
		return jsonResultsArray.toString();
	}
	
	@PostMapping(value="/member/request-accept-reject")
	private String RequestAcceptAndRejected(@Validated @RequestBody RequestMemberModel requestMemberModel) {
		JSONArray jsonResultsArray=new JSONArray();
		jsonResultsArray= requestMemberService.RequestAcceptAndRejected(requestMemberModel);
		return jsonResultsArray.toString();
	}
	
	@PostMapping(value="/member/block-member")
	private String BlockMember(@Validated @RequestBody RequestMemberModel requestMemberModel) {
		JSONArray jsonResultsArray=new JSONArray();
		jsonResultsArray= requestMemberService.blockMember(requestMemberModel);
		return jsonResultsArray.toString();
	}
}
