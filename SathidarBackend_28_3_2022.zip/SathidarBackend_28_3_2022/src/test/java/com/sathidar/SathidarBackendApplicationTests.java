package com.sathidar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SathidarBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
