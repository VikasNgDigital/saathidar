-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: sathidar
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cast`
--

DROP TABLE IF EXISTS `cast`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cast` (
  `cast_id` int NOT NULL AUTO_INCREMENT,
  `cast_name` varchar(150) DEFAULT NULL,
  `religion_id` int DEFAULT NULL,
  `status` varchar(45) DEFAULT 'ACTIVE',
  `created_by` varchar(45) DEFAULT NULL,
  `updated_by` varchar(45) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`cast_id`),
  KEY `religion_id_idx` (`religion_id`),
  CONSTRAINT `fk_religion_id` FOREIGN KEY (`religion_id`) REFERENCES `religion` (`religion_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cast`
--

LOCK TABLES `cast` WRITE;
/*!40000 ALTER TABLE `cast` DISABLE KEYS */;
INSERT INTO `cast` VALUES (1,'Maratha',1,'ACTIVE',NULL,NULL,'2022-03-23 09:36:04','2022-03-23 09:36:04'),(2,'Sonar',1,'ACTIVE',NULL,NULL,'2022-03-24 05:22:03','2022-03-24 05:22:03');
/*!40000 ALTER TABLE `cast` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `city` (
  `city_id` int NOT NULL AUTO_INCREMENT,
  `city_name` varchar(150) DEFAULT NULL,
  `status` varchar(45) DEFAULT 'ACTIVE',
  `created_by` varchar(45) DEFAULT NULL,
  `updated_by` varchar(45) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `state_id` int DEFAULT NULL,
  PRIMARY KEY (`city_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city`
--

LOCK TABLES `city` WRITE;
/*!40000 ALTER TABLE `city` DISABLE KEYS */;
INSERT INTO `city` VALUES (1,'Nashik','ACTIVE',NULL,NULL,'2022-03-23 09:37:41','2022-03-23 09:37:41',1),(2,'Pune','ACTIVE',NULL,NULL,'2022-03-24 05:21:13','2022-03-24 05:21:13',1);
/*!40000 ALTER TABLE `city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hide_content`
--

DROP TABLE IF EXISTS `hide_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hide_content` (
  `id` int NOT NULL AUTO_INCREMENT,
  `member_id` int DEFAULT NULL,
  `column_name` varchar(200) DEFAULT NULL,
  `status` varchar(45) DEFAULT 'ACTIVE',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hide_content`
--

LOCK TABLES `hide_content` WRITE;
/*!40000 ALTER TABLE `hide_content` DISABLE KEYS */;
INSERT INTO `hide_content` VALUES (1,13,'weight,income','ACTIVE'),(2,11,'weight,income,state,city','DEACTIVATE'),(3,11,'weight,income,state','ACTIVE');
/*!40000 ALTER TABLE `hide_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `member_id` int NOT NULL AUTO_INCREMENT,
  `member_number` varchar(45) DEFAULT NULL,
  `first_name` varchar(45) DEFAULT NULL,
  `middle_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `gender` varchar(45) DEFAULT NULL,
  `marital_status` varchar(200) DEFAULT NULL,
  `contact_number` varchar(45) DEFAULT NULL,
  `email_id` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT 'ACTIVE',
  `created_by` varchar(200) DEFAULT NULL,
  `updated_by` varchar(200) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `plan_id` int DEFAULT NULL,
  `role_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `profilecreatedby` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (1,NULL,'radha',NULL,'aher','female',NULL,'8600156895','radha@gmail.com','ACTIVE',NULL,NULL,'2022-03-17 13:46:26','2022-03-17 13:46:26',NULL,1,25,'father'),(2,NULL,'radha',NULL,'aher','female',NULL,'8600156895','radha@gmail.com','ACTIVE',NULL,NULL,'2022-03-17 13:46:38','2022-03-17 13:46:38',NULL,1,25,'father'),(3,NULL,'pankaj',NULL,'aher','male',NULL,'8600156895','pankaj@gmail.com','ACTIVE',NULL,NULL,'2022-03-17 13:48:13','2022-03-17 13:48:13',NULL,1,26,'self'),(4,NULL,'amit',NULL,'amit','male',NULL,'8600156895','amit@gmail.com','ACTIVE',NULL,NULL,'2022-03-18 05:30:50','2022-03-18 05:30:50',NULL,1,27,'son'),(5,NULL,'puja',NULL,'puja','female',NULL,'8600156895','puja@gmail.com','ACTIVE',NULL,NULL,'2022-03-18 05:42:31','2022-03-18 05:42:31',NULL,1,28,'self'),(6,NULL,'sai',NULL,'aher','male',NULL,'8600156895','sai@gmail.com','ACTIVE',NULL,NULL,'2022-03-18 10:15:20','2022-03-18 10:15:20',NULL,1,29,'self'),(10,'MSD010','prakash',NULL,'aher','male',NULL,'8600156895','prakash@gmail.com','ACTIVE',NULL,NULL,'2022-03-18 10:26:50','2022-03-18 10:26:50',NULL,1,33,'self'),(11,'MSD011','durgesh',NULL,'sonar','male',NULL,'8600156895','durgesh@gmail.com','ACTIVE',NULL,NULL,'2022-03-18 10:55:25','2022-03-18 10:55:25',NULL,1,34,'self'),(12,'FSD012','sayali',NULL,'sonar','female',NULL,'8600156895','sayali@gmail.com','ACTIVE',NULL,NULL,'2022-03-18 11:32:04','2022-03-18 11:32:04',NULL,1,35,'self'),(13,'MSD013','gaurav',NULL,'sonawane','male',NULL,'8600156895','gaurav@gmail.com','ACTIVE',NULL,NULL,'2022-03-25 06:25:28','2022-03-25 06:25:28',NULL,1,36,'self'),(14,'MSD014','gaurav',NULL,'sonawane','male',NULL,'8600156895','gaurav@gmail.com','ACTIVE',NULL,NULL,'2022-03-25 12:20:06','2022-03-25 12:20:06',NULL,1,37,'self');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_preference`
--

DROP TABLE IF EXISTS `member_preference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_preference` (
  `member_preference_id` int NOT NULL AUTO_INCREMENT,
  `member_id` int DEFAULT NULL,
  `gender` varchar(45) DEFAULT NULL,
  `agebetween` varchar(45) DEFAULT NULL,
  `lifestyle` varchar(45) DEFAULT NULL,
  `job` varchar(45) DEFAULT NULL,
  `education` varchar(45) DEFAULT NULL,
  `cast_id` int DEFAULT NULL,
  `subcaste_id` int DEFAULT NULL,
  `religion_id` int DEFAULT NULL,
  `state_id` int DEFAULT NULL,
  `city_id` int DEFAULT NULL,
  `fromage` int DEFAULT NULL,
  `toage` int DEFAULT NULL,
  `status` varchar(45) DEFAULT 'ACTIVE',
  PRIMARY KEY (`member_preference_id`),
  KEY `member_id_idx` (`member_id`),
  KEY `cast_id_idx` (`cast_id`),
  KEY `subcaste_id_idx` (`subcaste_id`),
  KEY `religion_id_idx` (`religion_id`),
  KEY `state_id_idx` (`state_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_preference`
--

LOCK TABLES `member_preference` WRITE;
/*!40000 ALTER TABLE `member_preference` DISABLE KEYS */;
INSERT INTO `member_preference` VALUES (1,13,'male',NULL,'healty,strong','Government,non-government','MCS',1,1,1,1,1,20,35,'ACTIVE'),(2,14,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ACTIVE');
/*!40000 ALTER TABLE `member_preference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_request`
--

DROP TABLE IF EXISTS `member_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_request` (
  `id` int NOT NULL AUTO_INCREMENT,
  `request_from_id` int DEFAULT NULL,
  `request_to_id` int DEFAULT NULL,
  `request_status` varchar(45) DEFAULT NULL,
  `block_by_id` int DEFAULT NULL,
  `block_status` varchar(45) DEFAULT NULL,
  `created_by` varchar(45) DEFAULT NULL,
  `updated_by` varchar(45) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_request`
--

LOCK TABLES `member_request` WRITE;
/*!40000 ALTER TABLE `member_request` DISABLE KEYS */;
INSERT INTO `member_request` VALUES (1,12,13,'Accepted',11,'un-Block',NULL,NULL,'2022-03-28 11:21:04','2022-03-28 11:21:04'),(3,11,13,'Accepted',11,'Block',NULL,NULL,'2022-03-28 13:17:37','2022-03-28 13:17:37'),(4,10,13,'Rejected',10,'Block',NULL,NULL,'2022-03-28 13:17:51','2022-03-28 13:17:51');
/*!40000 ALTER TABLE `member_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `memberdetails`
--

DROP TABLE IF EXISTS `memberdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `memberdetails` (
  `id` int NOT NULL AUTO_INCREMENT,
  `member_id` int NOT NULL,
  `cast_id` int DEFAULT NULL,
  `subcaste_id` int DEFAULT NULL,
  `membernative` varchar(100) DEFAULT NULL,
  `height` double DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `religion_id` int DEFAULT NULL,
  `lifestyles` varchar(100) DEFAULT NULL,
  `known_languages` varchar(200) DEFAULT NULL,
  `education` varchar(500) DEFAULT NULL,
  `job` varchar(500) DEFAULT NULL,
  `city_id` int DEFAULT NULL,
  `state_id` int DEFAULT NULL,
  `income` varchar(45) DEFAULT NULL,
  `zodiac_sign` varchar(200) DEFAULT NULL,
  `hobbies` varchar(500) DEFAULT NULL,
  `expectations` varchar(500) DEFAULT NULL,
  `created_by` varchar(45) DEFAULT NULL,
  `updated_by` varchar(45) DEFAULT NULL,
  `mother_tounge` varchar(45) DEFAULT NULL,
  `no_of_children` varchar(45) DEFAULT NULL,
  `date_of_birth` varchar(45) DEFAULT NULL,
  `marital_status` varchar(45) DEFAULT NULL,
  `age` int DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `creation_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_member_id_idx` (`member_id`),
  KEY `fk_cast_id_idx` (`cast_id`),
  KEY `subcaste_id_idx` (`subcaste_id`),
  KEY `religion_id_idx` (`religion_id`),
  KEY `state_id_idx` (`state_id`),
  KEY `city_id_idx` (`city_id`),
  CONSTRAINT `cast_id` FOREIGN KEY (`cast_id`) REFERENCES `cast` (`cast_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `city_id` FOREIGN KEY (`city_id`) REFERENCES `city` (`city_id`),
  CONSTRAINT `member_id` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`),
  CONSTRAINT `religion_id` FOREIGN KEY (`religion_id`) REFERENCES `religion` (`religion_id`),
  CONSTRAINT `state_id` FOREIGN KEY (`state_id`) REFERENCES `states` (`state_id`),
  CONSTRAINT `subcaste_id` FOREIGN KEY (`subcaste_id`) REFERENCES `subcasts` (`subcast_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `memberdetails`
--

LOCK TABLES `memberdetails` WRITE;
/*!40000 ALTER TABLE `memberdetails` DISABLE KEYS */;
INSERT INTO `memberdetails` VALUES (1,5,1,1,'nashik road',5.65,60.65,1,'healthy','marathi,english,hindi','BCA,MCA,12th','Softwear Enginner',1,1,'5LPA',NULL,'listening song, playing sports, Drawing','good at decision making, self-made and very ambitious in life',NULL,NULL,NULL,NULL,NULL,'Never Married',38,'2022-03-18 05:43:53','2022-03-18 05:43:53'),(3,6,2,2,'pune',5,55,1,'healthy','marathi,english','10th,12th,BCS','cleark',2,1,'8LPA',NULL,'listening song, Drawing','good at decision making, self-made and very ambitious in life',NULL,NULL,'Marathi','','12-11-1992','Never Married',30,'2022-03-18 10:16:05','2022-03-18 10:16:05'),(4,10,1,1,'jail road,nashik',5.9,80,1,'healthy,Travel','marathi,hindi','BCA,MCA,12th,10th','cleark',1,1,'3LPA',NULL,'listening song, Drawing','good at decision making, self-made and very ambitious in life',NULL,NULL,NULL,NULL,NULL,'Never Married',25,'2022-03-18 10:27:08','2022-03-18 10:27:08'),(5,11,2,2,'pune',5,55,1,'healthy,Travel','marathi,english','10th,12th,BCS','cleark',2,1,'5LPA',NULL,'listening song, Drawing','good at decision making, self-made and very ambitious in life',NULL,NULL,'Marathi','','12-11-1992','Never Married',30,'2022-03-18 10:55:26','2022-03-18 10:55:26'),(6,12,1,1,'pune',5.22,55,1,'healthy,Travel','marathi,english','10th,12th','cleark',1,1,'5LPA',NULL,'listening song, Drawing','good at decision making, self-made and very ambitious in life',NULL,NULL,'Marathi','2','12-11-1992','Divorced',30,'2022-03-18 11:32:05','2022-03-18 11:32:05'),(7,13,1,1,'nashik road',4.8,55,1,'healthy','marathi,english,hindi','10th,12th,BCS,MCS','Government',1,1,'10LPA',NULL,'listening song, Drawing','good at decision making, self-made and very ambitious in life',NULL,NULL,'Marathi','2','12-11-1992','Divorced',28,'2022-03-25 06:25:38','2022-03-25 06:25:38'),(8,14,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-03-25 12:20:06','2022-03-25 12:20:06');
/*!40000 ALTER TABLE `memberdetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `memberstories`
--

DROP TABLE IF EXISTS `memberstories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `memberstories` (
  `story_id` int NOT NULL AUTO_INCREMENT,
  `member_id` int DEFAULT NULL,
  `story_submitted` varchar(45) DEFAULT NULL,
  `memberstories` varchar(45) DEFAULT NULL,
  `story_test` varchar(800) DEFAULT NULL,
  `created_by` varchar(45) DEFAULT NULL,
  `updated_by` varchar(45) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`story_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `memberstories`
--

LOCK TABLES `memberstories` WRITE;
/*!40000 ALTER TABLE `memberstories` DISABLE KEYS */;
/*!40000 ALTER TABLE `memberstories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plans`
--

DROP TABLE IF EXISTS `plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plans` (
  `plan_id` int NOT NULL AUTO_INCREMENT,
  `plan_name` varchar(500) DEFAULT NULL,
  `plan_validity` varchar(100) DEFAULT NULL,
  `plan_price` double DEFAULT NULL,
  `plan_discount` double DEFAULT NULL,
  `plan_status` varchar(45) DEFAULT 'ACTIVE',
  `created_by` varchar(45) DEFAULT NULL,
  `updated_by` varchar(45) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`plan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plans`
--

LOCK TABLES `plans` WRITE;
/*!40000 ALTER TABLE `plans` DISABLE KEYS */;
/*!40000 ALTER TABLE `plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `religion`
--

DROP TABLE IF EXISTS `religion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `religion` (
  `religion_id` int NOT NULL AUTO_INCREMENT,
  `religion_name` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT 'ACTIVE',
  `created_by` varchar(45) DEFAULT NULL,
  `updated_by` varchar(45) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`religion_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `religion`
--

LOCK TABLES `religion` WRITE;
/*!40000 ALTER TABLE `religion` DISABLE KEYS */;
INSERT INTO `religion` VALUES (1,'Hindu','ACTIVE',NULL,NULL,'2022-03-23 09:35:31','2022-03-23 09:35:31');
/*!40000 ALTER TABLE `religion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `role_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `role_status` varchar(45) DEFAULT 'ACTIVE',
  `created_by` varchar(45) DEFAULT NULL,
  `updated_by` varchar(45) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'USER','active',NULL,NULL,'2022-03-15 12:44:51','2022-03-15 12:44:51'),(2,'ADMIN','active',NULL,NULL,'2022-03-15 12:44:52','2022-03-15 12:44:52'),(3,'GUEST','active',NULL,NULL,'2022-03-15 12:44:52','2022-03-15 12:44:52');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `states`
--

DROP TABLE IF EXISTS `states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `states` (
  `state_id` int NOT NULL AUTO_INCREMENT,
  `state_name` varchar(150) DEFAULT NULL,
  `status` varchar(45) DEFAULT 'ACTIVE',
  `created_by` varchar(45) DEFAULT NULL,
  `updated_by` varchar(45) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`state_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `states`
--

LOCK TABLES `states` WRITE;
/*!40000 ALTER TABLE `states` DISABLE KEYS */;
INSERT INTO `states` VALUES (1,'Maharashtra','ACTIVE',NULL,NULL,'2022-03-23 09:37:04','2022-03-23 09:37:04');
/*!40000 ALTER TABLE `states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subcasts`
--

DROP TABLE IF EXISTS `subcasts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subcasts` (
  `subcast_id` int NOT NULL AUTO_INCREMENT,
  `subcast_name` varchar(150) DEFAULT NULL,
  `cast_id` int DEFAULT NULL,
  `status` varchar(45) DEFAULT 'ACTIVE',
  `created_by` varchar(45) DEFAULT NULL,
  `updated_by` varchar(45) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`subcast_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subcasts`
--

LOCK TABLES `subcasts` WRITE;
/*!40000 ALTER TABLE `subcasts` DISABLE KEYS */;
INSERT INTO `subcasts` VALUES (1,'Kunbi',1,'ACTIVE',NULL,NULL,'2022-03-23 09:36:28','2022-03-23 09:36:28'),(2,'Sonar',2,'ACTIVE',NULL,NULL,'2022-03-24 05:22:18','2022-03-24 05:22:18');
/*!40000 ALTER TABLE `subcasts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tempsendotp`
--

DROP TABLE IF EXISTS `tempsendotp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tempsendotp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `conactno` varchar(45) DEFAULT NULL,
  `otp` varchar(45) DEFAULT NULL,
  `datetime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tempsendotp`
--

LOCK TABLES `tempsendotp` WRITE;
/*!40000 ALTER TABLE `tempsendotp` DISABLE KEYS */;
INSERT INTO `tempsendotp` VALUES (1,'8600170187','452195','2022-03-19 11:48:25'),(2,'8600170187','403379','2022-03-19 11:53:42'),(3,'8600170187','943197','2022-03-20 02:09:40'),(4,'8600170187','872690','2022-03-20 02:18:11'),(5,'8600170187','189748','2022-03-21 12:39:49'),(6,'8600170187','476742','2022-03-23 04:47:18');
/*!40000 ALTER TABLE `tempsendotp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(500) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `role` varchar(45) DEFAULT NULL,
  `deleteflag` char(1) DEFAULT 'N',
  `datetime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_At` timestamp NULL DEFAULT NULL,
  `updated_At` timestamp NULL DEFAULT NULL,
  `confirmation_Token` varchar(200) DEFAULT NULL,
  `is_Temp_Password` tinyint DEFAULT NULL,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `enabled` tinyint DEFAULT NULL,
  `gender` varchar(45) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `profilecreatedby` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT 'ACTIVE',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'vikas','{bcrypt}$2a$10$3cMoAKO2OVy62p1DvyatQOb0W2uDhv4jHch1p0mIGYboFy7xl3DLK','vikas@gmail.com','USER','N','2022-03-14 18:39:07','2022-03-14 18:39:08','2022-03-14 19:06:03','admin1',0,'vikas','aher',1,NULL,NULL,NULL,'ACTIVE'),(2,'pratik','{bcrypt}$2a$10$2NlOe76uXe4Qny10tF.O0uqzxzS3MAejkasKKq5LLbFRwbVkksowm','pratik@gmail.com','ADMIN','N','2022-03-15 04:44:37','2022-03-15 04:44:36','2022-03-15 04:48:41','admin2',0,'pratik','aher',1,NULL,NULL,NULL,'ACTIVE'),(3,'mihir','{bcrypt}$2a$10$Fdcd03x7NHBa0R6Mik7qP.ssUgCZjO9uN5WaGK/Kr7UsjPCtPlXqa','mihir@gmail.com','USER','N','2022-03-15 06:56:45','2022-03-15 06:56:45','2022-03-15 06:56:45','06d4531d-16f2-4619-8a50-7473ea7726ec',0,'mihir','aher',1,NULL,NULL,NULL,'ACTIVE'),(4,'nikhil','{bcrypt}$2a$10$YNldkh9A88/7uHqkfrpxjOffI7xFsqDGKMTxB7turXB6U1bNl6Bc2','nikhil@gmail.com','USER','N','2022-03-15 07:20:11','2022-03-15 07:20:11','2022-03-15 07:23:34','nkadmiin',0,'nikhil','Gujrathi',1,NULL,NULL,NULL,'ACTIVE'),(5,'kiran','{bcrypt}$2a$10$rJLbrt5AcS573YlrUO0B4e1R85TWs8ol0hBazSab6OdfXdXPqwy5G','kiran@gmail.com','USER','N','2022-03-16 05:16:49','2022-03-16 05:16:49','2022-03-16 05:16:49','3172573b-230a-448a-93de-7e5355e3f2fd',0,'kiran','pawar',1,NULL,NULL,NULL,'ACTIVE'),(6,'kiranp','{bcrypt}$2a$10$0OKOQL3dOp.eJyj.v2.ikuy3P0J5DHrKvxd9nyZHrjCfoJdbp6R/G','kiran@gmail.com','USER','N','2022-03-16 05:22:05','2022-03-16 05:22:05','2022-03-16 05:22:05','69dcd0ce-1a4a-4e3d-8895-055551fc1382',0,'kiran','pawar',1,NULL,NULL,NULL,'ACTIVE'),(7,'rahul','{bcrypt}$2a$10$20jXiDHxQhhdTSCfMQ1vz.g5/DJBwdCow15FpqSDma/Ni3spb9Tze','rahul@gmail.com','USER','N','2022-03-17 05:11:54','2022-03-17 05:11:53','2022-03-17 05:11:53','e443831b-a69f-4803-80e5-cd40f0886712',0,'rahul','pawar',1,NULL,NULL,NULL,'ACTIVE'),(8,'rahul1','{bcrypt}$2a$10$KVBma0QTTFOywHxhrfRpEO76./BeOfuryVTw3aKPChWS0Ml4n8yRS','rahul@gmail.com','USER','N','2022-03-17 05:23:43','2022-03-17 05:23:43','2022-03-17 05:23:43','2d365ccb-b3d1-4ea7-a3e3-6194eee45aee',0,'rahul1','pawar',1,NULL,NULL,NULL,'ACTIVE'),(9,'rahul2','{bcrypt}$2a$10$SVI41vWN/alpigXW.SErEe9d56aeYU0tYg8oA3X2qGLKPqpJWmo3e','rahul@gmail.com','USER','N','2022-03-17 05:44:01','2022-03-17 05:43:59','2022-03-17 05:43:59','6107abf2-789e-4c7e-b57e-90913ad08cc6',0,'rahul2','pawar',1,NULL,NULL,NULL,'ACTIVE'),(10,'rahul3','{bcrypt}$2a$10$wE63puUGDW62tgo/1GLBP.Bkn/NsbAEeq8gz3OU4q6SQsa2flgdUq','rahul@gmail.com','USER','N','2022-03-17 05:59:44','2022-03-17 05:59:44','2022-03-17 05:59:44','0e104fc7-53bb-4362-96e9-05404ea024d4',0,'rahul2','pawar',1,NULL,NULL,NULL,'ACTIVE'),(11,'rahul4','{bcrypt}$2a$10$rPCVP6yyvJF0mKGFrEnAaeoT26TZp8k.G7w23jSFVJxMTGl18b/ze','rahul@gmail.com','USER','N','2022-03-17 06:18:07','2022-03-17 06:18:07','2022-03-17 06:18:07','9cb28408-6e3e-47ce-b8b2-57bca2bafde6',0,'rahul4','pawar',1,NULL,NULL,NULL,'ACTIVE'),(12,'rahul5','{bcrypt}$2a$10$2DgSFaJYnCo7iMUqRVs0feNR34O1slPpUn3vgxo.qTHsyAl9SHUaK','rahul@gmail.com','USER','N','2022-03-17 06:19:59','2022-03-17 06:19:59','2022-03-17 06:19:59','634a2071-23db-438b-988a-5bc1a331d741',0,'rahul5','pawar',1,NULL,NULL,NULL,'ACTIVE'),(13,'rahul6','{bcrypt}$2a$10$tCMwusfnGFWkKwUyAbhZhOpvRhwXE7uzgaIFTQab1r2fm4.//4Z8q','rahul@gmail.com','USER','N','2022-03-17 06:21:16','2022-03-17 06:21:16','2022-03-17 06:21:16','27cec027-9b7b-4e56-8b0c-762af9e3cca5',0,'rahul6','pawar',1,NULL,NULL,NULL,'ACTIVE'),(14,'rahul7','{bcrypt}$2a$10$yj8dih19Hj6e29439D7a1uLj95ZPyvEVjNRXLFWsSgMLVN50v8E5C','rahul@gmail.com','USER','N','2022-03-17 06:25:39','2022-03-17 06:25:40','2022-03-17 06:25:40','4b70805f-79ad-4419-8c5b-14d73b8bdfaa',0,'rahul7','pawar',1,NULL,NULL,NULL,'ACTIVE'),(15,'rahul8','{bcrypt}$2a$10$RoDDgr8wDGrqEoHr2poKLuF2iKNm3.8hCXHUh8Gm0T2CAPTsYKgiW','rahul@gmail.com','USER','N','2022-03-17 06:29:50','2022-03-17 06:29:51','2022-03-17 06:29:51','acb61bc6-080a-4e97-8cff-6afe87b0105e',0,'rahul8','pawar',1,NULL,NULL,NULL,'ACTIVE'),(16,'rahul9','{bcrypt}$2a$10$wPH/I9OVCUa1KFhhML.sp.leOI1EyMLgv168IiCHSBA1AtV7Wn.Ce','rahul@gmail.com','ADMIN','N','2022-03-17 06:32:22','2022-03-17 06:32:23','2022-03-17 06:32:23','0a66ef4d-354f-45d7-b370-203257e18c2c',0,'rahul9','pawar',1,NULL,NULL,NULL,'ACTIVE'),(17,'rahul10','{bcrypt}$2a$10$zUZ70TdhjeBc0KNrg9rNEu7tDGt4QELQ9VK1kFBjBfMEbQlvDeJ52','rahul@gmail.com','ADMIN','N','2022-03-17 06:39:03','2022-03-17 06:39:04','2022-03-17 06:39:04','e64d4e74-3682-485e-88aa-d6e7c16cc9fd',0,'rahul10','pawar',1,NULL,NULL,NULL,'ACTIVE'),(18,'rahul11','{bcrypt}$2a$10$jJBOOC2XGC5vYgN3mf6EK.GbmF9CEq9y1nupKLJ6AOPbNH6Oba7qS','rahul@gmail.com','ADMIN','N','2022-03-17 06:41:07','2022-03-17 06:41:08','2022-03-17 06:41:08','72137782-e44a-4858-a4b0-871a12de9b6c',0,'rahul11','pawar',1,NULL,NULL,NULL,'ACTIVE'),(19,'aman','{bcrypt}$2a$10$y.hJL88jirNf1ae5UG.quuM1.3r.Kt8nYkxj4ZgQ6P5I4DIWV2lge','aman@gmail.com','ADMIN','N','2022-03-17 07:23:23','2022-03-17 07:23:24','2022-03-17 07:23:24','2b10cabe-3f1b-4179-a1a8-663ca2238920',0,'aman','pawar',1,NULL,NULL,NULL,'ACTIVE'),(20,'rajvi','{bcrypt}$2a$10$TEzc1s0gXIp6cH4XCPvlGOYKoKlDtYZVDpGBnuoBhUi.aTUlDGUHq','rajvi@gmail.com','USER','N','2022-03-17 12:27:50','2022-03-17 12:27:50','2022-03-17 12:27:50','1c375ac2-863a-47f1-a35e-8eca1391f98d',0,'rajvi','aher',1,'female','8600156895','self','ACTIVE'),(21,'janavi','{bcrypt}$2a$10$UoSlx0Toim8xKR24vSm/ROmmEvR.8Y4mHaknhuEnRzgxUFd5KQzdy','janavi@gmail.com','USER','N','2022-03-17 13:00:29','2022-03-17 13:00:28','2022-03-17 13:00:28','9398b914-e13c-4c26-a56d-cbb1f8e81b76',0,'janavi','aher',1,'female','8600156895','self','ACTIVE'),(22,'kunal','{bcrypt}$2a$10$u/BOe5EFBuFmUdBj3jPHC..zfbtld4L5I4k3q3eD2MKNVu2FyfiCa','kunal@gmail.com','USER','N','2022-03-17 13:28:16','2022-03-17 13:28:15','2022-03-17 13:28:15','b5482ec2-fc2d-4dcb-b116-33e025ac8561',0,'kunal','aher',1,'male','8600156895','father','ACTIVE'),(25,'radha','{bcrypt}$2a$10$LIssCFq4Eo9yiue9dZ227e9ur.0.qHif.DNxY/MlhS.2R20bbpwCq','radha@gmail.com','USER','N','2022-03-17 13:46:04','2022-03-17 13:46:04','2022-03-17 13:46:04','cd45b033-8af9-4c18-9ef3-80c6235768c6',0,'radha','aher',1,'female','8600156895','father','ACTIVE'),(26,'pankaj','{bcrypt}$2a$10$YHpswHmbjd2GmzjPyD/L2.o8KWoX8Y09aStDtIYVYGYKDwis8lH2S','pankaj@gmail.com','USER','N','2022-03-17 13:48:08','2022-03-17 13:48:08','2022-03-17 13:48:08','21870d02-30d9-4b6d-a51b-eed47ff8ffc4',0,'pankaj','aher',1,'male','8600156895','self','ACTIVE'),(27,'amit','{bcrypt}$2a$10$MRsLeQDQUymPVTKGANW5Ru1V8ur7Slyj6Xqi8ngdNL.CbtFGhrFhW','amit@gmail.com','USER','N','2022-03-18 05:30:28','2022-03-18 05:30:28','2022-03-18 05:30:28','979180b3-4991-43f6-a517-b14cf1d3b525',0,'amit','amit',1,'male','8600156895','son','ACTIVE'),(28,'puja','{bcrypt}$2a$10$LUlY4YalNTawtJUkl0ocEuDNSS/8fwR2i6pofivcM6uvE6XwgAaSe','puja@gmail.com','USER','N','2022-03-18 05:42:14','2022-03-18 05:42:14','2022-03-18 05:42:14','1e12cd6b-100f-4f54-963b-7dec0dc83820',0,'puja','puja',1,'female','8600156895','self','ACTIVE'),(29,'sai','{bcrypt}$2a$10$dtNGGnMbQhOZaE75FWXjvODJJDvm.wPamyz5m4tFL0Uk1V6kwelbC','sai@gmail.com','USER','N','2022-03-18 10:15:16','2022-03-18 10:15:16','2022-03-18 10:15:16','7cdefa4e-b41c-453a-95fa-a13ba3d4b168',0,'sai','aher',1,'male','8600156895','self','ACTIVE'),(33,'prakash','{bcrypt}$2a$10$cr0OfuxWUqKxpQmhFNyD9upFrOKe/XMBckn8.RT8SpX1mg90VQDTq','prakash@gmail.com','USER','N','2022-03-18 10:26:47','2022-03-18 10:26:48','2022-03-18 10:26:48','fc9b4c79-3f2a-4448-8e54-c0558256035c',0,'prakash','aher',1,'male','8600156895','self','ACTIVE'),(34,'durgesh','{bcrypt}$2a$10$0K/dd9sIH7XKzKr037CzseP2q6go0yL8UEZzWlkl66k.Cs.PFWxjK','durgesh@gmail.com','USER','N','2022-03-18 10:55:24','2022-03-18 10:55:24','2022-03-18 10:55:24','13773e98-8713-4103-8b55-396aba90d5e0',0,'durgesh','sonar',1,'male','8600156895','self','ACTIVE'),(35,'sayali','{bcrypt}$2a$10$KIjfwdXKQRWZOB9htvPPFuE8MWbnqDX/Kl0wJ.IDHI30.iVGYkeoG','sayali@gmail.com','USER','N','2022-03-18 11:32:02','2022-03-18 11:32:03','2022-03-18 11:32:03','b70fcfa7-2c4d-4706-b79a-0633652de85f',0,'sayali','sonar',1,'female','8600156895','self','ACTIVE'),(36,'gaurav','{bcrypt}$2a$10$iWSEOiMXoM2fPG6gfeSPNuxFONGNFi.oGdXP6QXj0GdD5kYNVgfoS','gaurav@gmail.com','USER','N','2022-03-25 06:25:24','2022-03-25 06:25:24','2022-03-25 06:25:24','009c132e-3438-4de1-acb8-f90cd9c2ea5a',0,'gaurav','sonawane',1,'male','8600156895','self','ACTIVE'),(37,'durgesh','{bcrypt}$2a$10$2u.kvepPgZXC9ccDSgDOReUu8WBla4S5SEVUtMKeKtwWBAbVkXN7W','gaurav@gmail.com','USER','N','2022-03-25 12:20:05','2022-03-25 12:20:06','2022-03-25 12:20:06','71f32038-9cd2-4a00-881e-ce28210a7fb4',0,'gaurav','sonawane',1,'male','8600156895','self','');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_roles`
--

DROP TABLE IF EXISTS `users_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `role_id` int DEFAULT NULL,
  `creadted_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(45) DEFAULT 'ACTIVE',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_roles`
--

LOCK TABLES `users_roles` WRITE;
/*!40000 ALTER TABLE `users_roles` DISABLE KEYS */;
INSERT INTO `users_roles` VALUES (1,1,1,'2022-03-15 12:46:36','ACTIVE'),(2,2,2,'2022-03-15 12:46:36','ACTIVE'),(3,3,1,'2022-03-15 12:46:36','ACTIVE'),(4,4,3,'2022-03-15 12:46:36','ACTIVE'),(6,1,0,'2022-03-17 05:25:16','ACTIVE'),(7,1,0,'2022-03-17 06:00:20','ACTIVE'),(8,1,0,'2022-03-17 06:00:31','ACTIVE'),(9,0,1,'2022-03-17 06:18:52','ACTIVE'),(10,0,1,'2022-03-17 06:20:31','ACTIVE'),(11,0,1,'2022-03-17 06:24:16','ACTIVE'),(12,14,2,'2022-03-17 06:25:52','ACTIVE'),(13,15,2,'2022-03-17 06:29:55','ACTIVE'),(14,16,2,'2022-03-17 06:32:28','ACTIVE'),(15,17,2,'2022-03-17 06:39:25','ACTIVE'),(16,20,1,'2022-03-17 12:29:17','ACTIVE'),(17,21,1,'2022-03-17 13:01:05','ACTIVE'),(18,22,1,'2022-03-17 13:28:37','ACTIVE'),(21,25,1,'2022-03-17 13:46:04','ACTIVE'),(22,26,1,'2022-03-17 13:48:08','ACTIVE'),(23,27,1,'2022-03-18 05:30:29','ACTIVE'),(24,28,1,'2022-03-18 05:42:14','ACTIVE'),(25,29,1,'2022-03-18 10:15:18','ACTIVE'),(29,33,1,'2022-03-18 10:26:47','ACTIVE'),(30,34,1,'2022-03-18 10:55:25','ACTIVE'),(31,35,1,'2022-03-18 11:32:04','ACTIVE'),(32,36,1,'2022-03-25 06:25:26','ACTIVE'),(33,37,1,'2022-03-25 12:20:06','ACTIVE');
/*!40000 ALTER TABLE `users_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'sathidar'
--

--
-- Dumping routines for database 'sathidar'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-28 18:59:37
